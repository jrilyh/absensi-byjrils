# Absensi Siswa - Vercel

## Upload ke GitHub
Upload semua isi folder ini ke satu repository:
- index.html
- api/absen.js
- vercel.json

## Environment Variables di Vercel
Tambahkan:
- TELEGRAM_BOT_TOKEN = token bot Telegram kamu
- TELEGRAM_CHAT_ID = 2088712028

Jangan menaruh token bot di index.html.
