export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method tidak diizinkan' });

  const { name, date, time } = req.body || {};
  if (!name || !date || !time) return res.status(400).json({ error: 'Data absensi belum lengkap' });

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) return res.status(500).json({ error: 'Environment Telegram belum diatur di Vercel' });

  const message =
`📋 ABSENSI SISWA
👤 Nama: ${name}
📅 Tanggal: ${date}
🕐 Waktu: ${time} WIB
✅ Status: Hadir`;

  try {
    const tg = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: message })
    });

    const result = await tg.json();
    if (!tg.ok || !result.ok) return res.status(502).json({ error: 'Telegram gagal menerima absensi' });

    return res.status(200).json({ ok: true });
  } catch {
    return res.status(500).json({ error: 'Gagal menghubungi Telegram' });
  }
}
